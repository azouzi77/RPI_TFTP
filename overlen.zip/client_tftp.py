"""
Client TFTP
"""
import binascii
import socket
import struct
import sys

def dataSend(sock, req, fileName, loss):
    if req == 'get':
        opCode = 0x01
    elif req == 'put':
        opCode = 0x02
    request = str(opCode) + fileName + str(0x0) + 'octet' + str(0x0)
    sock.send(request)
"""
    request = (opCode, fileName, bytearray(1), 'octet', bytearray(1))
    packer = struct.Struct('I 2s f')
    packed_data = packer.pack(*request)
    sock.sendall(packed_data)
"""

def connect(dns, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = (dns, port)
    print >>sys.stderr, 'connecting to %s port %s' % server_address
    sock.connect(server_address)
    return sock

while 1:
    print 'usage: mytftpc <put/get> <nom_DNS_du_serveur> <numero_de_port> <nom_fichier> <taux_de_perte>'
    var = raw_input(">> ")
    
    func, req, dns, port, fileName, loss = var.split(" ", 5)
    
    if func == 'mytftpc':
        if req == 'put' or \
           req == 'get':
            sock = connect(dns, int(port))
            dataSend(sock, req, fileName, loss)
            
    
print >>sys.stderr, 'closing socket'
sock.close()
